export const CUSTOMER_STATUS = {
  lead: { label: 'Lead', cls: 'bg-amber-100 text-amber-800 ring-amber-200' },
  active: { label: 'Faol', cls: 'bg-emerald-100 text-emerald-800 ring-emerald-200' },
  inactive: { label: 'Nofaol', cls: 'bg-slate-100 text-slate-600 ring-slate-200' },
}

export const DEAL_STAGES = [
  { key: 'new', label: 'Yangi', dot: 'bg-sky-500', cls: 'bg-sky-100 text-sky-800 ring-sky-200' },
  { key: 'negotiation', label: 'Muzokara', dot: 'bg-amber-500', cls: 'bg-amber-100 text-amber-800 ring-amber-200' },
  { key: 'won', label: 'Yutilgan', dot: 'bg-emerald-500', cls: 'bg-emerald-100 text-emerald-800 ring-emerald-200' },
  { key: 'lost', label: "Yo'qotilgan", dot: 'bg-rose-500', cls: 'bg-rose-100 text-rose-800 ring-rose-200' },
]

export const STAGE_BY_KEY = Object.fromEntries(DEAL_STAGES.map((s) => [s.key, s]))

export const STORAGE_KEY = 'mini-crm:v1'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const PHONE_RE = /^\+?[0-9\s\-()]{7,20}$/

export function validateCustomer(v, existingCustomers = [], currentId = null) {
  const errors = {}
  const name = v.name.trim()
  const email = v.email.trim().toLowerCase()
  const phone = v.phone.trim()

  if (!name) errors.name = 'Ism majburiy'
  else if (name.length < 2) errors.name = "Ism kamida 2 ta belgidan iborat bo'lishi kerak"
  else if (name.length > 60) errors.name = "Ism 60 belgidan oshmasligi kerak"

  if (!email) errors.email = 'Email majburiy'
  else if (!EMAIL_RE.test(email)) errors.email = "Email noto'g'ri formatda (masalan: ism@kompaniya.uz)"
  else if (existingCustomers.some((c) => c.id !== currentId && c.email.toLowerCase() === email))
    errors.email = 'Bu email bilan mijoz allaqachon mavjud'

  if (!phone) errors.phone = 'Telefon raqam majburiy'
  else if (!PHONE_RE.test(phone)) errors.phone = "Telefon noto'g'ri (masalan: +998 90 123 45 67)"

  if (v.company.trim().length > 80) errors.company = 'Kompaniya nomi 80 belgidan oshmasligi kerak'

  if (!['lead', 'active', 'inactive'].includes(v.status)) errors.status = 'Holatni tanlang'

  return errors
}

export function validateDeal(v) {
  const errors = {}
  const title = v.title.trim()
  const amount = Number(v.amount)

  if (!title) errors.title = 'Bitim nomi majburiy'
  else if (title.length < 3) errors.title = "Nom kamida 3 ta belgidan iborat bo'lishi kerak"
  else if (title.length > 80) errors.title = 'Nom 80 belgidan oshmasligi kerak'

  if (v.amount === '' || v.amount === null) errors.amount = 'Summa majburiy'
  else if (Number.isNaN(amount)) errors.amount = "Summa raqam bo'lishi kerak"
  else if (amount <= 0) errors.amount = "Summa 0 dan katta bo'lishi kerak"
  else if (amount > 1_000_000_000) errors.amount = 'Summa juda katta'

  if (!v.customerId) errors.customerId = 'Mijozni tanlang'
  if (!v.stage) errors.stage = 'Bosqichni tanlang'

  return errors
}

export function validateNote(text) {
  const t = text.trim()
  if (!t) return 'Yozuv matni bo\'sh bo\'lmasligi kerak'
  if (t.length > 500) return 'Yozuv 500 belgidan oshmasligi kerak'
  return ''
}

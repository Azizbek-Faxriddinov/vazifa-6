import { createContext, useCallback, useContext, useEffect, useMemo, useReducer } from 'react'
import { STORAGE_KEY } from '../utils/constants'
import { uid } from '../utils/format'

const CrmContext = createContext(null)

const initialState = {
  status: 'loading', // loading | ready | error
  error: null,
  customers: [],
  deals: [],
}

function reducer(state, action) {
  switch (action.type) {
    case 'LOADING':
      return { ...initialState }
    case 'LOADED':
      return { status: 'ready', error: null, customers: action.customers, deals: action.deals }
    case 'FAILED':
      return { ...state, status: 'error', error: action.error }

    case 'ADD_CUSTOMER':
      return { ...state, customers: [action.customer, ...state.customers] }
    case 'UPDATE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.map((c) => (c.id === action.id ? { ...c, ...action.changes } : c)),
      }
    case 'DELETE_CUSTOMER':
      return {
        ...state,
        customers: state.customers.filter((c) => c.id !== action.id),
        deals: state.deals.filter((d) => d.customerId !== action.id),
      }

    case 'ADD_NOTE':
      return {
        ...state,
        customers: state.customers.map((c) =>
          c.id === action.customerId ? { ...c, notes: [action.note, ...c.notes] } : c,
        ),
      }
    case 'DELETE_NOTE':
      return {
        ...state,
        customers: state.customers.map((c) =>
          c.id === action.customerId ? { ...c, notes: c.notes.filter((n) => n.id !== action.noteId) } : c,
        ),
      }

    case 'ADD_DEAL':
      return { ...state, deals: [action.deal, ...state.deals] }
    case 'UPDATE_DEAL':
      return {
        ...state,
        deals: state.deals.map((d) => (d.id === action.id ? { ...d, ...action.changes } : d)),
      }
    case 'DELETE_DEAL':
      return { ...state, deals: state.deals.filter((d) => d.id !== action.id) }

    default:
      return state
  }
}

const wait = (ms) => new Promise((r) => setTimeout(r, ms))

function readStorage() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw)
    if (Array.isArray(parsed?.customers) && Array.isArray(parsed?.deals)) return parsed
  } catch {
    // buzilgan ma'lumot — e'tiborsiz qoldiriladi va qayta yuklanadi
  }
  return null
}

async function loadData() {
  await wait(700) // skeleton ko'rinishi uchun kichik kechikish
  const saved = readStorage()
  if (saved) return saved

  const res = await fetch('/data/crm.json')
  if (!res.ok) throw new Error(`Serverdan ma'lumot olinmadi (${res.status})`)
  const data = await res.json()
  if (!Array.isArray(data.customers) || !Array.isArray(data.deals)) {
    throw new Error("Ma'lumotlar tuzilmasi noto'g'ri")
  }
  return data
}

export function CrmProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)

  const load = useCallback(() => {
    let cancelled = false
    dispatch({ type: 'LOADING' })
    loadData()
      .then((data) => {
        if (!cancelled) dispatch({ type: 'LOADED', customers: data.customers, deals: data.deals })
      })
      .catch((err) => {
        if (!cancelled) dispatch({ type: 'FAILED', error: err.message || "Noma'lum xatolik" })
      })
    return () => {
      cancelled = true
    }
  }, [])

  useEffect(() => load(), [load])

  // localStorage ga avtomatik saqlash
  useEffect(() => {
    if (state.status !== 'ready') return
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ customers: state.customers, deals: state.deals }),
      )
    } catch {
      // xotira to'lgan yoki bloklangan bo'lishi mumkin
    }
  }, [state.status, state.customers, state.deals])

  const actions = useMemo(
    () => ({
      retry: load,
      resetDemo: () => {
        try {
          localStorage.removeItem(STORAGE_KEY)
        } catch {
          /* ignore */
        }
        load()
      },
      addCustomer: (values) => {
        const customer = {
          id: uid(),
          name: values.name.trim(),
          email: values.email.trim().toLowerCase(),
          phone: values.phone.trim(),
          company: values.company.trim(),
          status: values.status,
          createdAt: new Date().toISOString(),
          notes: [],
        }
        dispatch({ type: 'ADD_CUSTOMER', customer })
        return customer
      },
      updateCustomer: (id, values) =>
        dispatch({
          type: 'UPDATE_CUSTOMER',
          id,
          changes: {
            name: values.name.trim(),
            email: values.email.trim().toLowerCase(),
            phone: values.phone.trim(),
            company: values.company.trim(),
            status: values.status,
          },
        }),
      deleteCustomer: (id) => dispatch({ type: 'DELETE_CUSTOMER', id }),
      addNote: (customerId, text) =>
        dispatch({
          type: 'ADD_NOTE',
          customerId,
          note: { id: uid(), text: text.trim(), createdAt: new Date().toISOString() },
        }),
      deleteNote: (customerId, noteId) => dispatch({ type: 'DELETE_NOTE', customerId, noteId }),
      addDeal: (values) =>
        dispatch({
          type: 'ADD_DEAL',
          deal: {
            id: uid(),
            customerId: values.customerId,
            title: values.title.trim(),
            amount: Number(values.amount),
            stage: values.stage,
            createdAt: new Date().toISOString(),
          },
        }),
      updateDeal: (id, changes) => dispatch({ type: 'UPDATE_DEAL', id, changes }),
      deleteDeal: (id) => dispatch({ type: 'DELETE_DEAL', id }),
    }),
    [load],
  )

  const value = useMemo(() => ({ ...state, ...actions }), [state, actions])

  return <CrmContext.Provider value={value}>{children}</CrmContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useCrm() {
  const ctx = useContext(CrmContext)
  if (!ctx) throw new Error('useCrm faqat CrmProvider ichida ishlatiladi')
  return ctx
}

import { useId } from 'react'

const INPUT_BASE =
  'block w-full rounded-lg border bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 transition focus:outline-none focus:ring-2'

export function FormField({ label, error, touched, required, as = 'input', children, ...props }) {
  const id = useId()
  const showError = Boolean(error) && touched
  const cls = `${INPUT_BASE} ${
    showError
      ? 'border-rose-400 focus:border-rose-500 focus:ring-rose-200'
      : 'border-slate-300 focus:border-brand-500 focus:ring-brand-100'
  }`
  const common = {
    id,
    className: cls,
    'aria-invalid': showError || undefined,
    'aria-describedby': showError ? `${id}-err` : undefined,
    ...props,
  }

  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium text-slate-700">
        {label}
        {required && <span className="ml-0.5 text-rose-500">*</span>}
      </label>
      {as === 'select' ? (
        <select {...common}>{children}</select>
      ) : as === 'textarea' ? (
        <textarea rows={3} {...common} />
      ) : (
        <input {...common} />
      )}
      {showError && (
        <p id={`${id}-err`} className="mt-1 flex items-center gap-1 text-xs font-medium text-rose-600">
          <span aria-hidden="true">⚠</span> {error}
        </p>
      )}
    </div>
  )
}

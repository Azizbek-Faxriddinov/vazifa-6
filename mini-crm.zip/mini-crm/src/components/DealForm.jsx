import { useMemo, useState } from 'react'
import { FormField } from './FormField'
import { Button } from './ui'
import { validateDeal } from '../utils/validation'
import { DEAL_STAGES } from '../utils/constants'
import { useCrm } from '../context/CrmContext'

export function DealForm({ fixedCustomerId, onSubmit, onCancel }) {
  const { customers } = useCrm()
  const [values, setValues] = useState({
    title: '',
    amount: '',
    customerId: fixedCustomerId ?? '',
    stage: 'new',
  })
  const [touched, setTouched] = useState({})

  const errors = useMemo(() => validateDeal(values), [values])

  const bind = (field) => ({
    name: field,
    value: values[field],
    onChange: (e) => setValues((v) => ({ ...v, [field]: e.target.value })),
    onBlur: () => setTouched((t) => ({ ...t, [field]: true })),
    error: errors[field],
    touched: touched[field],
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    setTouched({ title: true, amount: true, customerId: true, stage: true })
    if (Object.keys(errors).length > 0) return
    onSubmit(values)
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-4">
      <FormField label="Bitim nomi" required placeholder="Masalan: Veb-sayt ishlab chiqish" {...bind('title')} />
      <FormField
        label="Summa (USD)"
        required
        type="number"
        inputMode="decimal"
        min="0"
        step="any"
        placeholder="5000"
        {...bind('amount')}
      />
      {!fixedCustomerId && (
        <FormField label="Mijoz" required as="select" {...bind('customerId')}>
          <option value="">— Mijozni tanlang —</option>
          {customers.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
              {c.company ? ` · ${c.company}` : ''}
            </option>
          ))}
        </FormField>
      )}
      <FormField label="Bosqich" required as="select" {...bind('stage')}>
        {DEAL_STAGES.map((s) => (
          <option key={s.key} value={s.key}>
            {s.label}
          </option>
        ))}
      </FormField>

      <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onCancel}>
          Bekor qilish
        </Button>
        <Button type="submit">Bitim qo'shish</Button>
      </div>
    </form>
  )
}

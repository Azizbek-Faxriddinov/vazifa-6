import { useMemo, useState } from 'react'
import { FormField } from './FormField'
import { Button } from './ui'
import { validateCustomer } from '../utils/validation'
import { CUSTOMER_STATUS } from '../utils/constants'
import { useCrm } from '../context/CrmContext'

const EMPTY = { name: '', email: '', phone: '', company: '', status: 'lead' }

export function CustomerForm({ customer, onSubmit, onCancel }) {
  const { customers } = useCrm()
  const [values, setValues] = useState(() =>
    customer
      ? {
          name: customer.name,
          email: customer.email,
          phone: customer.phone,
          company: customer.company,
          status: customer.status,
        }
      : EMPTY,
  )
  const [touched, setTouched] = useState({})

  const errors = useMemo(
    () => validateCustomer(values, customers, customer?.id ?? null),
    [values, customers, customer],
  )

  const set = (field) => (e) => setValues((v) => ({ ...v, [field]: e.target.value }))
  const blur = (field) => () => setTouched((t) => ({ ...t, [field]: true }))
  const bind = (field) => ({
    name: field,
    value: values[field],
    onChange: set(field),
    onBlur: blur(field),
    error: errors[field],
    touched: touched[field],
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    setTouched({ name: true, email: true, phone: true, company: true, status: true })
    if (Object.keys(errors).length > 0) return
    onSubmit(values)
  }

  return (
    <form onSubmit={handleSubmit} noValidate className="space-y-4">
      <FormField label="To'liq ism" required placeholder="Masalan: Aziz Karimov" autoComplete="name" {...bind('name')} />
      <FormField
        label="Email"
        required
        type="email"
        placeholder="ism@kompaniya.uz"
        autoComplete="email"
        {...bind('email')}
      />
      <FormField
        label="Telefon"
        required
        type="tel"
        placeholder="+998 90 123 45 67"
        autoComplete="tel"
        {...bind('phone')}
      />
      <FormField label="Kompaniya" placeholder="Ixtiyoriy" {...bind('company')} />
      <FormField label="Holat" required as="select" {...bind('status')}>
        {Object.entries(CUSTOMER_STATUS).map(([key, s]) => (
          <option key={key} value={key}>
            {s.label}
          </option>
        ))}
      </FormField>

      <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
        <Button variant="secondary" onClick={onCancel}>
          Bekor qilish
        </Button>
        <Button type="submit">{customer ? 'Saqlash' : "Mijoz qo'shish"}</Button>
      </div>
    </form>
  )
}

import { NavLink, Outlet } from 'react-router-dom'

const LINKS = [
  { to: '/', label: 'Boshqaruv', icon: '📊', end: true },
  { to: '/customers', label: 'Mijozlar', icon: '👥' },
  { to: '/deals', label: 'Bitimlar', icon: '💼' },
]

const sideCls = ({ isActive }) =>
  `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
    isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-100'
  }`

const tabCls = ({ isActive }) =>
  `flex flex-1 flex-col items-center gap-0.5 py-2 text-xs font-medium ${
    isActive ? 'text-brand-600' : 'text-slate-500'
  }`

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600 text-lg font-bold text-white">
        M
      </div>
      <span className="text-lg font-bold tracking-tight text-slate-900">Mini CRM</span>
    </div>
  )
}

export default function Layout() {
  return (
    <div className="min-h-screen md:flex">
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-slate-200 bg-white p-4 md:flex">
        <div className="px-2 py-3">
          <Logo />
        </div>
        <nav className="mt-4 flex flex-col gap-1" aria-label="Asosiy navigatsiya">
          {LINKS.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={sideCls}>
              <span aria-hidden="true">{l.icon}</span>
              {l.label}
            </NavLink>
          ))}
        </nav>
        <p className="mt-auto px-2 text-xs text-slate-400">Ma'lumotlar brauzeringizda saqlanadi.</p>
      </aside>

      {/* Mobile header */}
      <header className="sticky top-0 z-30 flex items-center border-b border-slate-200 bg-white px-4 py-3 md:hidden">
        <Logo />
      </header>

      <main className="min-w-0 flex-1 px-4 pb-28 pt-6 sm:px-6 md:pb-10 lg:px-10">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>

      {/* Mobile bottom tabs */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 flex border-t border-slate-200 bg-white pb-[env(safe-area-inset-bottom)] md:hidden"
        aria-label="Mobil navigatsiya"
      >
        {LINKS.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end} className={tabCls}>
            <span className="text-lg" aria-hidden="true">
              {l.icon}
            </span>
            {l.label}
          </NavLink>
        ))}
      </nav>
    </div>
  )
}

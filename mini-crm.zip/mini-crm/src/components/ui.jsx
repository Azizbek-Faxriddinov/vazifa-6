import { CUSTOMER_STATUS, STAGE_BY_KEY } from '../utils/constants'
import { initials } from '../utils/format'

const BTN_BASE =
  'inline-flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50'

const BTN_VARIANTS = {
  primary: 'bg-brand-600 text-white hover:bg-brand-700 focus-visible:ring-brand-500',
  secondary: 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus-visible:ring-slate-400',
  danger: 'bg-rose-600 text-white hover:bg-rose-700 focus-visible:ring-rose-500',
  ghost: 'text-slate-600 hover:bg-slate-100 focus-visible:ring-slate-400',
}

export function Button({ variant = 'primary', className = '', type = 'button', ...props }) {
  return <button type={type} className={`${BTN_BASE} ${BTN_VARIANTS[variant]} ${className}`} {...props} />
}

export function Badge({ className = '', children }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ring-inset ${className}`}
    >
      {children}
    </span>
  )
}

export function StatusBadge({ status }) {
  const s = CUSTOMER_STATUS[status] ?? CUSTOMER_STATUS.inactive
  return <Badge className={s.cls}>{s.label}</Badge>
}

export function StageBadge({ stage }) {
  const s = STAGE_BY_KEY[stage]
  if (!s) return null
  return (
    <Badge className={s.cls}>
      <span className={`h-1.5 w-1.5 rounded-full ${s.dot}`} />
      {s.label}
    </Badge>
  )
}

export function Avatar({ name, size = 'md' }) {
  const sizes = { md: 'h-11 w-11 text-sm', lg: 'h-16 w-16 text-xl' }
  return (
    <div
      className={`flex shrink-0 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-700 ${sizes[size]}`}
      aria-hidden="true"
    >
      {initials(name)}
    </div>
  )
}

export function Card({ className = '', children }) {
  return <div className={`rounded-2xl border border-slate-200 bg-white ${className}`}>{children}</div>
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {action}
    </div>
  )
}

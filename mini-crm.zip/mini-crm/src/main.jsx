import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import './index.css'
import App from './App.jsx'
import { CrmProvider } from './context/CrmContext.jsx'
import { ToastProvider } from './context/ToastContext.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <ToastProvider>
        <CrmProvider>
          <App />
        </CrmProvider>
      </ToastProvider>
    </BrowserRouter>
  </StrictMode>,
)

import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { useCrm } from '../context/CrmContext'
import { useToast } from '../context/ToastContext'
import { Avatar, Button, Card, StageBadge, StatusBadge } from '../components/ui'
import { DetailSkeleton } from '../components/Skeleton'
import { EmptyState, ErrorState } from '../components/StateViews'
import { ConfirmDialog, Modal } from '../components/Modal'
import { CustomerForm } from '../components/CustomerForm'
import { DealForm } from '../components/DealForm'
import { FormField } from '../components/FormField'
import { validateNote } from '../utils/validation'
import { formatDate, formatMoney } from '../utils/format'

function NoteForm({ onAdd }) {
  const [text, setText] = useState('')
  const [touched, setTouched] = useState(false)
  const error = validateNote(text)

  const submit = (e) => {
    e.preventDefault()
    setTouched(true)
    if (error) return
    onAdd(text)
    setText('')
    setTouched(false)
  }

  return (
    <form onSubmit={submit} noValidate className="space-y-3">
      <FormField
        as="textarea"
        label="Yangi yozuv"
        placeholder="Qo'ng'iroq, uchrashuv yoki eslatma…"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={() => setTouched(true)}
        error={error}
        touched={touched}
      />
      <div className="flex items-center justify-between">
        <span className={`text-xs ${text.length > 500 ? 'text-rose-600' : 'text-slate-400'}`}>
          {text.length}/500
        </span>
        <Button type="submit">Yozuv qo'shish</Button>
      </div>
    </form>
  )
}

export default function CustomerDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const { push } = useToast()
  const {
    status,
    error,
    customers,
    deals,
    retry,
    updateCustomer,
    deleteCustomer,
    addNote,
    deleteNote,
    addDeal,
    deleteDeal,
  } = useCrm()

  const [modal, setModal] = useState(null) // 'edit' | 'delete' | 'deal'
  const [dealToDelete, setDealToDelete] = useState(null)

  if (status === 'loading') return <DetailSkeleton />
  if (status === 'error') return <ErrorState message={error} onRetry={retry} />

  const customer = customers.find((c) => c.id === id)
  if (!customer) {
    return (
      <EmptyState
        icon="🙈"
        title="Mijoz topilmadi"
        text="Bu mijoz o'chirilgan yoki mavjud emas."
        action={
          <Link
            to="/customers"
            className="inline-flex rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
          >
            Mijozlar ro'yxatiga qaytish
          </Link>
        }
      />
    )
  }

  const customerDeals = deals.filter((d) => d.customerId === customer.id)

  return (
    <div className="space-y-6">
      <Link to="/customers" className="inline-flex items-center gap-1 text-sm font-medium text-slate-500 hover:text-slate-900">
        ← Mijozlar
      </Link>

      <Card className="p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <Avatar name={customer.name} size="lg" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900">{customer.name}</h1>
              <StatusBadge status={customer.status} />
            </div>
            <p className="text-sm text-slate-500">{customer.company || "Kompaniya ko'rsatilmagan"}</p>
            <p className="mt-2 break-all text-sm text-slate-600">
              ✉️ {customer.email} <span className="mx-1 text-slate-300">|</span> 📞 {customer.phone}
            </p>
            <p className="mt-1 text-xs text-slate-400">Qo'shilgan: {formatDate(customer.createdAt)}</p>
          </div>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={() => setModal('edit')}>
              Tahrirlash
            </Button>
            <Button variant="danger" onClick={() => setModal('delete')}>
              O'chirish
            </Button>
          </div>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-semibold text-slate-900">Bitimlar ({customerDeals.length})</h2>
            <Button variant="secondary" onClick={() => setModal('deal')} className="px-3 py-1.5">
              + Bitim
            </Button>
          </div>
          {customerDeals.length === 0 ? (
            <p className="rounded-xl bg-slate-50 py-8 text-center text-sm text-slate-500">
              Bu mijoz uchun bitimlar yo'q.
            </p>
          ) : (
            <ul className="space-y-3">
              {customerDeals.map((d) => (
                <li key={d.id} className="flex items-start gap-3 rounded-xl border border-slate-200 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-900">{d.title}</p>
                    <p className="mt-0.5 text-sm text-slate-600">{formatMoney(d.amount)}</p>
                    <div className="mt-2">
                      <StageBadge stage={d.stage} />
                    </div>
                  </div>
                  <button
                    onClick={() => setDealToDelete(d)}
                    className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-500"
                    aria-label={`${d.title} bitimini o'chirish`}
                  >
                    🗑
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <h2 className="mb-4 text-base font-semibold text-slate-900">Yozuvlar ({customer.notes.length})</h2>
          <NoteForm
            onAdd={(text) => {
              addNote(customer.id, text)
              push("Yozuv qo'shildi")
            }}
          />
          {customer.notes.length === 0 ? (
            <p className="mt-5 rounded-xl bg-slate-50 py-6 text-center text-sm text-slate-500">
              Hali yozuvlar yo'q.
            </p>
          ) : (
            <ul className="mt-5 space-y-3">
              {customer.notes.map((n) => (
                <li key={n.id} className="rounded-xl bg-slate-50 p-3">
                  <p className="whitespace-pre-wrap break-words text-sm text-slate-800">{n.text}</p>
                  <div className="mt-2 flex items-center justify-between text-xs text-slate-400">
                    <span>{formatDate(n.createdAt)}</span>
                    <button
                      onClick={() => {
                        deleteNote(customer.id, n.id)
                        push("Yozuv o'chirildi")
                      }}
                      className="font-medium text-slate-500 hover:text-rose-600"
                    >
                      O'chirish
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {modal === 'edit' && (
        <Modal title="Mijozni tahrirlash" onClose={() => setModal(null)}>
          <CustomerForm
            customer={customer}
            onCancel={() => setModal(null)}
            onSubmit={(values) => {
              updateCustomer(customer.id, values)
              setModal(null)
              push("O'zgarishlar saqlandi")
            }}
          />
        </Modal>
      )}

      {modal === 'deal' && (
        <Modal title="Yangi bitim" onClose={() => setModal(null)}>
          <DealForm
            fixedCustomerId={customer.id}
            onCancel={() => setModal(null)}
            onSubmit={(values) => {
              addDeal(values)
              setModal(null)
              push("Bitim qo'shildi")
            }}
          />
        </Modal>
      )}

      {modal === 'delete' && (
        <ConfirmDialog
          title="Mijozni o'chirish"
          message={`"${customer.name}" va unga tegishli ${customerDeals.length} ta bitim butunlay o'chiriladi. Bu amalni qaytarib bo'lmaydi.`}
          onCancel={() => setModal(null)}
          onConfirm={() => {
            deleteCustomer(customer.id)
            push("Mijoz o'chirildi")
            navigate('/customers', { replace: true })
          }}
        />
      )}

      {dealToDelete && (
        <ConfirmDialog
          title="Bitimni o'chirish"
          message={`"${dealToDelete.title}" bitimi o'chirilsinmi?`}
          onCancel={() => setDealToDelete(null)}
          onConfirm={() => {
            deleteDeal(dealToDelete.id)
            setDealToDelete(null)
            push("Bitim o'chirildi")
          }}
        />
      )}
    </div>
  )
}

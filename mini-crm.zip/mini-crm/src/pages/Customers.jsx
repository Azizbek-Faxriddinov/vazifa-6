import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useCrm } from '../context/CrmContext'
import { useToast } from '../context/ToastContext'
import { Avatar, Button, Card, PageHeader, StatusBadge } from '../components/ui'
import { CustomerGridSkeleton } from '../components/Skeleton'
import { EmptyState, ErrorState } from '../components/StateViews'
import { Modal } from '../components/Modal'
import { CustomerForm } from '../components/CustomerForm'
import { CUSTOMER_STATUS } from '../utils/constants'
import { formatDate } from '../utils/format'

export default function Customers() {
  const { status, error, customers, deals, retry, addCustomer } = useCrm()
  const { push } = useToast()
  const navigate = useNavigate()

  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('all')
  const [sort, setSort] = useState('newest')
  const [showForm, setShowForm] = useState(false)

  const dealCount = useMemo(() => {
    const map = {}
    deals.forEach((d) => {
      map[d.customerId] = (map[d.customerId] || 0) + 1
    })
    return map
  }, [deals])

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase()
    const list = customers.filter((c) => {
      if (filter !== 'all' && c.status !== filter) return false
      if (!q) return true
      return [c.name, c.email, c.phone, c.company].some((f) => f.toLowerCase().includes(q))
    })
    list.sort((a, b) =>
      sort === 'name' ? a.name.localeCompare(b.name) : b.createdAt.localeCompare(a.createdAt),
    )
    return list
  }, [customers, query, filter, sort])

  const handleCreate = (values) => {
    const c = addCustomer(values)
    setShowForm(false)
    push(`${c.name} qo'shildi`)
    navigate(`/customers/${c.id}`)
  }

  const hasFilters = query.trim() !== '' || filter !== 'all'
  const clearFilters = () => {
    setQuery('')
    setFilter('all')
  }

  return (
    <>
      <PageHeader
        title="Mijozlar"
        subtitle={status === 'ready' ? `Jami ${customers.length} ta mijoz` : 'Mijozlar ro\'yxati'}
        action={
          <Button onClick={() => setShowForm(true)} disabled={status !== 'ready'}>
            + Yangi mijoz
          </Button>
        }
      />

      {status === 'ready' && customers.length > 0 && (
        <Card className="mb-5 grid gap-3 p-3 sm:grid-cols-[1fr_auto_auto]">
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ism, email, telefon yoki kompaniya bo'yicha qidirish…"
            aria-label="Qidirish"
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm placeholder:text-slate-400 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            aria-label="Holat bo'yicha filtr"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            <option value="all">Barcha holatlar</option>
            {Object.entries(CUSTOMER_STATUS).map(([k, s]) => (
              <option key={k} value={k}>
                {s.label}
              </option>
            ))}
          </select>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            aria-label="Saralash"
            className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
          >
            <option value="newest">Eng yangilari</option>
            <option value="name">Ism bo'yicha (A–Z)</option>
          </select>
        </Card>
      )}

      {status === 'loading' && <CustomerGridSkeleton />}
      {status === 'error' && <ErrorState message={error} onRetry={retry} />}

      {status === 'ready' && customers.length === 0 && (
        <EmptyState
          icon="👥"
          title="Hali mijozlar yo'q"
          text="Birinchi mijozingizni qo'shib, savdo jarayonini boshlang."
          action={<Button onClick={() => setShowForm(true)}>+ Yangi mijoz</Button>}
        />
      )}

      {status === 'ready' && customers.length > 0 && visible.length === 0 && (
        <EmptyState
          icon="🔍"
          title="Hech narsa topilmadi"
          text="Qidiruv yoki filtr shartlariga mos mijoz yo'q."
          action={
            hasFilters && (
              <Button variant="secondary" onClick={clearFilters}>
                Filtrlarni tozalash
              </Button>
            )
          }
        />
      )}

      {status === 'ready' && visible.length > 0 && (
        <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((c) => (
            <li key={c.id}>
              <Link
                to={`/customers/${c.id}`}
                className="block h-full rounded-2xl border border-slate-200 bg-white p-4 transition hover:border-brand-500 hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
              >
                <div className="flex items-center gap-3">
                  <Avatar name={c.name} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold text-slate-900">{c.name}</p>
                    <p className="truncate text-xs text-slate-500">{c.company || 'Kompaniya ko\'rsatilmagan'}</p>
                  </div>
                  <StatusBadge status={c.status} />
                </div>
                <dl className="mt-4 space-y-1 text-sm text-slate-600">
                  <div className="flex gap-2">
                    <dt aria-label="Email">✉️</dt>
                    <dd className="truncate">{c.email}</dd>
                  </div>
                  <div className="flex gap-2">
                    <dt aria-label="Telefon">📞</dt>
                    <dd>{c.phone}</dd>
                  </div>
                </dl>
                <p className="mt-3 text-xs text-slate-400">
                  {dealCount[c.id] || 0} ta bitim · {formatDate(c.createdAt)}
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}

      {showForm && (
        <Modal title="Yangi mijoz" onClose={() => setShowForm(false)}>
          <CustomerForm onSubmit={handleCreate} onCancel={() => setShowForm(false)} />
        </Modal>
      )}
    </>
  )
}

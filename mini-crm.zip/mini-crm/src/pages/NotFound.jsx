import { Link } from 'react-router-dom'
import { EmptyState } from '../components/StateViews'

export default function NotFound() {
  return (
    <EmptyState
      icon="🧭"
      title="Sahifa topilmadi"
      text="Siz izlagan manzil mavjud emas yoki ko'chirilgan."
      action={
        <Link
          to="/"
          className="inline-flex rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
        >
          Bosh sahifaga qaytish
        </Link>
      }
    />
  )
}

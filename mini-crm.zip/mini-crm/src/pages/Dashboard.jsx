import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { useCrm } from '../context/CrmContext'
import { Avatar, Button, Card, PageHeader, StatusBadge } from '../components/ui'
import { DashboardSkeleton } from '../components/Skeleton'
import { EmptyState, ErrorState } from '../components/StateViews'
import { DEAL_STAGES } from '../utils/constants'
import { formatDate, formatMoney } from '../utils/format'

function Stat({ label, value, hint }) {
  return (
    <Card className="p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-2 text-2xl font-bold text-slate-900">{value}</p>
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </Card>
  )
}

export default function Dashboard() {
  const { status, error, customers, deals, retry, resetDemo } = useCrm()

  const stats = useMemo(() => {
    const open = deals.filter((d) => d.stage === 'new' || d.stage === 'negotiation')
    const won = deals.filter((d) => d.stage === 'won')
    const byStage = DEAL_STAGES.map((s) => {
      const list = deals.filter((d) => d.stage === s.key)
      return { ...s, count: list.length, sum: list.reduce((a, d) => a + d.amount, 0) }
    })
    return {
      total: customers.length,
      active: customers.filter((c) => c.status === 'active').length,
      leads: customers.filter((c) => c.status === 'lead').length,
      openSum: open.reduce((a, d) => a + d.amount, 0),
      openCount: open.length,
      wonSum: won.reduce((a, d) => a + d.amount, 0),
      byStage,
      maxCount: Math.max(1, ...byStage.map((s) => s.count)),
      recent: [...customers].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5),
    }
  }, [customers, deals])

  return (
    <>
      <PageHeader
        title="Boshqaruv paneli"
        subtitle="Biznesingizning umumiy ko'rinishi"
        action={
          <Link
            to="/customers"
            className="inline-flex items-center justify-center rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand-700"
          >
            Mijozlarga o'tish
          </Link>
        }
      />

      {status === 'loading' && <DashboardSkeleton />}
      {status === 'error' && <ErrorState message={error} onRetry={retry} />}

      {status === 'ready' && customers.length === 0 && deals.length === 0 && (
        <EmptyState
          icon="🚀"
          title="Hozircha ma'lumot yo'q"
          text="Birinchi mijozingizni qo'shing yoki demo ma'lumotlarni qayta yuklang."
          action={
            <div className="flex flex-col gap-2 sm:flex-row">
              <Link
                to="/customers"
                className="inline-flex items-center justify-center rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
              >
                Mijoz qo'shish
              </Link>
              <Button variant="secondary" onClick={resetDemo}>
                Demo ma'lumotlarni yuklash
              </Button>
            </div>
          }
        />
      )}

      {status === 'ready' && (customers.length > 0 || deals.length > 0) && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <Stat label="Jami mijozlar" value={stats.total} hint={`${stats.leads} ta lead`} />
            <Stat label="Faol mijozlar" value={stats.active} />
            <Stat label="Ochiq bitimlar" value={formatMoney(stats.openSum)} hint={`${stats.openCount} ta bitim`} />
            <Stat label="Yutilgan summa" value={formatMoney(stats.wonSum)} />
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="p-5">
              <h2 className="text-base font-semibold text-slate-900">Bitimlar bosqichlar bo'yicha</h2>
              <ul className="mt-4 space-y-4">
                {stats.byStage.map((s) => (
                  <li key={s.key}>
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="font-medium text-slate-700">{s.label}</span>
                      <span className="text-slate-500">
                        {s.count} ta · {formatMoney(s.sum)}
                      </span>
                    </div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
                      <div
                        className={`h-full rounded-full ${s.dot}`}
                        style={{ width: `${(s.count / stats.maxCount) * 100}%` }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            </Card>

            <Card className="p-5">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-semibold text-slate-900">So'nggi mijozlar</h2>
                <Link to="/customers" className="text-sm font-medium text-brand-600 hover:underline">
                  Barchasi
                </Link>
              </div>
              {stats.recent.length === 0 ? (
                <p className="mt-6 text-center text-sm text-slate-500">Mijozlar yo'q</p>
              ) : (
                <ul className="mt-3 divide-y divide-slate-100">
                  {stats.recent.map((c) => (
                    <li key={c.id}>
                      <Link
                        to={`/customers/${c.id}`}
                        className="flex items-center gap-3 rounded-lg py-3 transition hover:bg-slate-50"
                      >
                        <Avatar name={c.name} />
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-slate-900">{c.name}</p>
                          <p className="truncate text-xs text-slate-500">
                            {c.company || c.email} · {formatDate(c.createdAt)}
                          </p>
                        </div>
                        <StatusBadge status={c.status} />
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>

          <div className="text-right">
            <Button variant="ghost" onClick={resetDemo} className="text-xs">
              Demo ma'lumotlarni tiklash
            </Button>
          </div>
        </div>
      )}
    </>
  )
}

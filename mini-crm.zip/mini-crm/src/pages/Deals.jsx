import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useCrm } from '../context/CrmContext'
import { useToast } from '../context/ToastContext'
import { Button, PageHeader } from '../components/ui'
import { DealsSkeleton } from '../components/Skeleton'
import { EmptyState, ErrorState } from '../components/StateViews'
import { ConfirmDialog, Modal } from '../components/Modal'
import { DealForm } from '../components/DealForm'
import { DEAL_STAGES } from '../utils/constants'
import { formatMoney } from '../utils/format'

export default function Deals() {
  const { status, error, deals, customers, retry, addDeal, updateDeal, deleteDeal } = useCrm()
  const { push } = useToast()
  const [showForm, setShowForm] = useState(false)
  const [toDelete, setToDelete] = useState(null)

  const customerById = useMemo(() => Object.fromEntries(customers.map((c) => [c.id, c])), [customers])

  const columns = useMemo(
    () =>
      DEAL_STAGES.map((s) => {
        const list = deals.filter((d) => d.stage === s.key)
        return { ...s, list, sum: list.reduce((a, d) => a + d.amount, 0) }
      }),
    [deals],
  )

  const canAdd = status === 'ready' && customers.length > 0

  return (
    <>
      <PageHeader
        title="Bitimlar"
        subtitle="Savdo jarayoni bosqichlar bo'yicha"
        action={
          <Button onClick={() => setShowForm(true)} disabled={!canAdd}>
            + Yangi bitim
          </Button>
        }
      />

      {status === 'loading' && <DealsSkeleton />}
      {status === 'error' && <ErrorState message={error} onRetry={retry} />}

      {status === 'ready' && customers.length === 0 && (
        <EmptyState
          icon="💼"
          title="Avval mijoz qo'shing"
          text="Bitim yaratish uchun kamida bitta mijoz bo'lishi kerak."
          action={
            <Link
              to="/customers"
              className="inline-flex rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700"
            >
              Mijozlarga o'tish
            </Link>
          }
        />
      )}

      {status === 'ready' && customers.length > 0 && deals.length === 0 && (
        <EmptyState
          icon="💼"
          title="Hali bitimlar yo'q"
          text="Birinchi bitimni yarating va savdo jarayonini kuzating."
          action={<Button onClick={() => setShowForm(true)}>+ Yangi bitim</Button>}
        />
      )}

      {status === 'ready' && deals.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {columns.map((col) => (
            <section key={col.key} className="rounded-2xl bg-slate-100/70 p-3" aria-label={col.label}>
              <header className="mb-3 flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${col.dot}`} />
                  <h2 className="text-sm font-semibold text-slate-800">{col.label}</h2>
                  <span className="rounded-full bg-white px-2 py-0.5 text-xs font-medium text-slate-500">
                    {col.list.length}
                  </span>
                </div>
                <span className="text-xs font-medium text-slate-500">{formatMoney(col.sum)}</span>
              </header>

              {col.list.length === 0 ? (
                <p className="rounded-xl border border-dashed border-slate-300 py-6 text-center text-xs text-slate-400">
                  Bu bosqichda bitim yo'q
                </p>
              ) : (
                <ul className="space-y-3">
                  {col.list.map((d) => {
                    const c = customerById[d.customerId]
                    return (
                      <li key={d.id} className="rounded-xl border border-slate-200 bg-white p-3 shadow-sm">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-semibold text-slate-900">{d.title}</p>
                          <button
                            onClick={() => setToDelete(d)}
                            className="shrink-0 rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                            aria-label={`${d.title} bitimini o'chirish`}
                          >
                            🗑
                          </button>
                        </div>
                        <p className="mt-1 text-base font-bold text-brand-700">{formatMoney(d.amount)}</p>
                        {c ? (
                          <Link
                            to={`/customers/${c.id}`}
                            className="mt-1 block truncate text-xs text-slate-500 hover:text-brand-600 hover:underline"
                          >
                            {c.name}
                            {c.company ? ` · ${c.company}` : ''}
                          </Link>
                        ) : (
                          <p className="mt-1 text-xs text-slate-400">Mijoz topilmadi</p>
                        )}
                        <label className="mt-3 block">
                          <span className="sr-only">Bosqichni o'zgartirish</span>
                          <select
                            value={d.stage}
                            onChange={(e) => {
                              updateDeal(d.id, { stage: e.target.value })
                              push('Bosqich yangilandi')
                            }}
                            className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                          >
                            {DEAL_STAGES.map((s) => (
                              <option key={s.key} value={s.key}>
                                {s.label}
                              </option>
                            ))}
                          </select>
                        </label>
                      </li>
                    )
                  })}
                </ul>
              )}
            </section>
          ))}
        </div>
      )}

      {showForm && (
        <Modal title="Yangi bitim" onClose={() => setShowForm(false)}>
          <DealForm
            onCancel={() => setShowForm(false)}
            onSubmit={(values) => {
              addDeal(values)
              setShowForm(false)
              push("Bitim qo'shildi")
            }}
          />
        </Modal>
      )}

      {toDelete && (
        <ConfirmDialog
          title="Bitimni o'chirish"
          message={`"${toDelete.title}" bitimi o'chirilsinmi?`}
          onCancel={() => setToDelete(null)}
          onConfirm={() => {
            deleteDeal(toDelete.id)
            setToDelete(null)
            push("Bitim o'chirildi")
          }}
        />
      )}
    </>
  )
}
